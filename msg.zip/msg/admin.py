from django.contrib import admin
from msg.models import *


@admin.register(Message)
class MerchantAdmin(admin.ModelAdmin):
    icon_name = 'Message'
    list_display = ('message', 'cr_on')

    def get_queryset(self, request):
        qs = super(MerchantAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            return qs
        return qs.filter(user=request.user)
