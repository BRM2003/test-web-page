import binascii
import hashlib
import hmac
import requests

from binascii import unhexlify
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.decorators import api_view
from rest_framework.response import Response
from itertools import product


@api_view(['POST'])
@csrf_exempt
def user1(request):
    data = {}
    key = '00112233445566778899AABBCCDDEEFF'
    if request.method == 'POST':
        values = ['amount', 'Currency', 'order', 'desc', 'merch_name',
                  'merch_url', 'merchant', 'terminal', 'email', 'trtype',
                  'country', 'merch_gmt', 'timestamp', 'nonce', 'backref']
        message = ''
        for el in range(0, len(values)):
            if request.data[values[el]] == '':
                message += '-'
            else:
                element = request.data[values[el]]
                message += str(len(element)) + element  # str(len(str(len(element))))
        data['message'] = message

        key = unhexlify(key)
        raw = str.encode(data['message'])
        mac = hmac.new(key, raw, hashlib.sha1).digest()

        data['cipher'] = binascii.hexlify(mac)
    return Response(data)


def read_msg(msg, len_variables):
    message = str(msg)
    result = []
    len_msg = 0

    def get_size(position):
        if message[position] == "-":
            return "error"
        else:
            return int(message[position])

    for i in range(0, len_variables):
        size_len = get_size(len_msg)

        if size_len == "error":
            txt = "-"
            len_msg += 1
        else:
            message_start = len_msg + size_len + 1
            if size_len == 2:
                message_end = int(message[len_msg + size_len - 1: size_len + len_msg + 1]) + len_msg + size_len + 1
                len_msg += int(message[len_msg + size_len - 1: size_len + len_msg + 1]) + size_len + 1
            else:
                message_end = int(message[len_msg + 1]) + len_msg + size_len + 1
                len_msg += int(message[len_msg + 1]) + size_len + 1
            txt = message[message_start: message_end]

        result.append(txt)
    return result


def decrypt_msg(msg, msg_size):
    result = []

    def check_result(result, positions):
        size = 0
        messages = 0
        for i in positions:
            size += i
        for el in result:
            messages += len(el)
        if size + messages == len(msg):
            return True
        else:
            return False

    def check_msg(pos):
        position = list(pos)
        len_msg = 0
        test_result = []
        for i in range(msg_size):
            size_len = position[i]
            message_start = len_msg + size_len

            try:
                if msg[len_msg] == '-':
                    position[i] = 1
                    len_msg += 1
                    test_result.append('')
                    continue

                if size_len == 1:
                    test_msg_len = int(msg[len_msg])
                else:
                    test_msg_len = int(msg[len_msg: len_msg + size_len])
                test_data = msg[message_start: message_start + test_msg_len]

                if i == msg_size - 1:
                    last_msg = msg[message_start: len(msg)]
                    if test_msg_len != len(last_msg):
                        break

                len_msg += test_msg_len + size_len
                test_result.append(test_data)
            except Exception as e:
                return 'Error'

        if check_result(test_result, position):
            return test_result
        else:
            return 'Error'

    for roll in product([1, 2], repeat=msg_size):
        result = check_msg(roll)
        if result != 'Error':
            break
    return result


@csrf_exempt
@api_view(['POST'])
def user2(request):
    response = {"TERMINAL": '', "ORDER": '', "AMOUNT": '', "CURRENCY": '', "ACTION": '', "RC": '',
                "MESSAGE": '', "APPROVAL": '', "RRN": '', "INT_REF": '', "TIMESTAMP": '', "TRTYPE": '',
                "NONCE": '', "P_SIGN": ''}
    response2 = ['amount', 'Currency', 'order', 'desc', 'merch_name',
              'merch_url', 'merchant', 'terminal', 'email', 'trtype',
              'country', 'merch_gmt', 'timestamp', 'nonce', 'backref']

    values = {'message', 'cipher'}
    key = '00112233445566778899AABBCCDDEEFF'
    algorithm = {'HMAC_SHA1', '3DES ABA/ABC CBC MAC', 'AES 128 CBC MAC', 'RAS/SHA1'}

    if values <= set(request.data):
        new_values = request.data
        print(new_values)

        try:
            mac = hmac.new(unhexlify(key), str.encode(new_values['message']), hashlib.sha1).digest()
            if new_values['cipher'] == binascii.hexlify(mac).decode("utf-8"):
                message = {}
                result = decrypt_msg(new_values['message'], len(response2))
                for i in range(0, len(response2)):
                    message[response2[i]] = result[i]
                print(message)
                response['MESSAGE'] = 'Approved'
            else:
                response['MESSAGE'] = 'Authentication failed'
        except Exception as e:
            response['MESSAGE'] = 'Authentication failed'
            print("Error: " + str(e))

    else:
        response['MESSAGE'] = 'Authentication failed'

    return Response(response)

    # print('\nuser 2\t' + request.method)
    # key = '00112233445566778899AABBCCDDEEFF'
    # if request.method == 'POST':
    #     if {"cipher", "message"} <= set(request.POST):
    #         try:
    #             mac = hmac.new(unhexlify(key), str.encode(request.POST['message']), hashlib.sha1).digest()
    #
    #             if request.POST['cipher'] == binascii.hexlify(mac).decode("utf-8"):
    #                 message = {}
    #                 values = ['AMOUNT', 'CURRENCY', 'ORDER', 'DESC', 'MERCH_NAME', 'MERCH_URL', 'MERCHANT', 'TERMINAL',
    #                           'EMAIL', 'TRTYPE', 'COUNTRY', 'MERCH_GMT', 'TIMESTAMP', 'NONCE', 'BACKREF']
    #                 result = read_msg(request.POST['message'], len(values))
    #                 for i in range(0, len(values)):
    #                     message[values[i]] = result[i]
    #                 print(message)
    #             else:
    #                 print("!!!Ciphers do not match!!!")
    #         except Exception as e:
    #             print("Error: " + str(e))
    #     else:
    #         print("error")
    # return render(request, 'messages/user2.html')
