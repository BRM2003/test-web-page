import binascii
import hashlib
import hmac
import random

import requests
from binascii import unhexlify
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt


# @api_view(['POST'])
@csrf_exempt
def user1(request):
    if request.method == 'POST':
        values = ['AMOUNT', 'CURRENCY', 'ORDER', 'DESC', 'MERCH_NAME', 'MERCH_URL', 'MERCHANT', 'TERMINAL',
                  'EMAIL', 'TRTYPE', 'COUNTRY', 'MERCH_GMT', 'TIMESTAMP', 'NONCE', 'BACKREF']
        message = ''
        for el in range(0, len(values)):
            if request.POST[values[el]] == '':
                message += '-'
            else:
                element = request.POST[values[el]]
                message += str(len(str(len(element)))) + str(len(element)) + element
        if {"key"} <= set(request.POST):
            # def nums():
            #     da = ''
            #     for i in range(0, 15):
            #         num = random.randint(0, 100000000000)
            #         print(num)
            #         da += str(len(str(len(str(num))))) + str(len(str(num))) + str(num)
            #     return da

            data = {'message': message}

            key = unhexlify(request.POST['key'])
            raw = str.encode(data['message'])
            mac = hmac.new(key, raw, hashlib.sha1).digest()

            data['cipher'] = binascii.hexlify(mac)

            print(data)
            requests.post("http://127.0.0.1:8000/sas/send_message/user2", data=data)
    return render(request, 'messages/user1.html')


def read_msg(msg, len_variables):
    message = str(msg)
    result = []
    len_msg = 0

    def get_size(position):
        if message[position] == "-":
            return "error"
        else:
            return int(message[position])

    for i in range(0, len_variables):
        size_len = get_size(len_msg)

        if size_len == "error":
            txt = "-"
            len_msg += 1
        else:
            message_start = len_msg + size_len + 1
            if size_len == 2:
                message_end = int(message[len_msg + size_len - 1: size_len + len_msg + 1]) + len_msg + size_len + 1
                len_msg += int(message[len_msg + size_len - 1: size_len + len_msg + 1]) + size_len + 1
            else:
                message_end = int(message[len_msg + 1]) + len_msg + size_len + 1
                len_msg += int(message[len_msg + 1]) + size_len + 1
            txt = message[message_start: message_end]

        result.append(txt)
    return result


@csrf_exempt
def user2(request):
    print('\nuser 2\t' + request.method)
    key = '00112233445566778899AABBCCDDEEFF'
    if request.method == 'POST':
        if {"cipher", "message"} <= set(request.POST):
            try:
                mac = hmac.new(unhexlify(key), str.encode(request.POST['message']), hashlib.sha1).digest()

                if request.POST['cipher'] == binascii.hexlify(mac).decode("utf-8"):
                    message = {}
                    values = ['AMOUNT', 'CURRENCY', 'ORDER', 'DESC', 'MERCH_NAME', 'MERCH_URL', 'MERCHANT', 'TERMINAL',
                              'EMAIL', 'TRTYPE', 'COUNTRY', 'MERCH_GMT', 'TIMESTAMP', 'NONCE', 'BACKREF']
                    result = read_msg(request.POST['message'], len(values))
                    for i in range(0, len(values)):
                        message[values[i]] = result[i]
                    print(message)
                else:
                    print("!!!Ciphers do not match!!!")
            except Exception as e:
                print("Error: " + str(e))
        else:
            print("error")
    return render(request, 'messages/user2.html')
